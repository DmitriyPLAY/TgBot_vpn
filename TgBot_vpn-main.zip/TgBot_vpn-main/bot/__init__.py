"""
Telegram VPN Bot - Main Application
Бот для продажи VPN подписок на российском рынке
"""